<footer class="footer py-2">
      <div class="">
        <p class="lead text-center"><strong>A Siyabonga Danson Mgwenya Production copyright&copy2019</strong></p>
      </div>
  </footer> 
  <script src="<?php echo base_url();?>assets/dist/js/bootstrap.js"></script>
  <script src="<?php echo base_url();?>assets/dist/js/popper.min.js"></script>
  <script src="<?php echo base_url();?>assets/dist/js/main.js"></script>
</body>
</html>